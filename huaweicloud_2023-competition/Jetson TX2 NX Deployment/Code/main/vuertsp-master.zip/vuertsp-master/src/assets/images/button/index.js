import closedEyes from "./closed-eyes.png";
import headTurn from "./head-turn.png";
import phoneWatch from "./phone-watch.png";
import yawnEmoji from "./yawn-emoji.png";

export {closedEyes, headTurn, phoneWatch, yawnEmoji};